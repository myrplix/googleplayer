<?php 
	include_once 'func.php';

	include_once 'php_fast_cache.php';

	include_once 'packer.php'; 
	
	include_once 'library.php';
?>